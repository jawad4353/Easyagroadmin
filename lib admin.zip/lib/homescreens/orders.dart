import 'package:flutter/material.dart';

class Orders extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Text('Orders'),
    );
  }

}